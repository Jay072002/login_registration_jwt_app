const router = require('express').Router();
const user_controller = require('../controller/usercontroller');
const { verifyToken } = require('../controller/jwt');


router.get('/', verifyToken, (req, res) => {
    res.render('home')
})



module.exports = router;