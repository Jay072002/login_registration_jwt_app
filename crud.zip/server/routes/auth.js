const router = require('express').Router();
const auth_controller = require('../controller/authcontroller');


// /auth/register route

//get request
router.get('/register', auth_controller.renderRegisterPage)

// post request
router.post('/register', auth_controller.registerAuth)


// /auth/login route

//get request
router.get('/login', auth_controller.renderLoginPage)

//post request
router.post('/login', auth_controller.loginAuth)


module.exports = router