const router = require('express').Router();
const admin_controller = require('../controller/admincontroller');


//  /auth/admin route
router.get('/admin', admin_controller.renderAdmin)


module.exports = router;