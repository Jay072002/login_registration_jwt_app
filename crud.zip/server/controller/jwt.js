const JWT = require('jsonwebtoken');

const generateToken = async (email) => {

    try {
        if (email) {
            const token = await JWT.sign(email, process.env.TOKEN_KEY);
            console.log(token);
            return token;
        } else {
            console.log('generateToken error');
        }
    } catch (err) {
        console.log(err);
    }

}

const verifyToken = (req, res, next) => {
    let token = req.cookies.userToken;
    if (token) {
        let data = JWT.verify(token, process.env.TOKEN_KEY);
        req.email = data.email
        next();
    } else {
        res.redirect('/auth/login');
    }
}

module.exports = { generateToken, verifyToken };