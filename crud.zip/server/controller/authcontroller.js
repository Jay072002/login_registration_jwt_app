
const { getData, insertData, getParticularData } = require('../models/user')
require('../models/db')
const bcrypt = require('bcrypt')
const { generateToken, verifyToken } = require('./jwt');

//------------------------------------------------------------------------------

// /auth/register

// get request
const renderRegisterPage = (req, res) => {
    res.render('index', {
        msg: ""
    })
}

// post request
const registerAuth = async (req, res) => {

    const username = req.body.username;
    const email = req.body.email;
    let password = req.body.password;

    try {
        password = await bcrypt.hash(password, 10);

        const result = await getParticularData(email) //returns an object

        if (result == null) {
            await insertData(username, email, password);

            res.redirect('/auth/login')
        } else {
            res.render('index', { msg: 'user already exists' })
        }

    } catch (err) {
        console.log(err);
    }

}

//------------------------------------------------------------------------------

// /auth/login

// get request
const renderLoginPage = (req, res) => {
    res.render('login', { msg: "" })
}

//post request

const loginAuth = async (req, res) => {

    const email = req.body.email;
    const password = req.body.password;

    try {
        const result = await getParticularData(email) //returns an object

        if (result == null) {
            res.render('login', { msg: "unauthorized access" })
        }
        let match = await bcrypt.compare(password, result.password);
        if (match) {
            let token = await generateToken(email);
            await res.cookie('userToken', token, { maxAge: 30000 });
            res.redirect('/')
        } else {
            res.render('login', { msg: "Incorrect password" });

        }

    } catch (err) {
        console.log(err);
    }

}




module.exports = {
    renderRegisterPage,
    registerAuth,
    renderLoginPage,
    loginAuth
}