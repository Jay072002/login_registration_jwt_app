const collection = require('../models/user')
require('../models/db')

// what to do when get req comes at / route

const homePage = async (req, res) => {
    res.render('index', { msg: "" })
}

module.exports = {
    homePage
}