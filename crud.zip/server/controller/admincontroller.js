require('../models/db')
require('../models/admin');

//--------------------------------------------------------------

// /auth/admin 

// get request
const renderAdmin = (req, res) => {
    res.render('admin_login')
}

module.exports = {
    renderAdmin
}