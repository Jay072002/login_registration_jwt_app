const mongoose = require('mongoose');
const validator = require('validator')


// user schema 

const adminSchema = new mongoose.Schema({

    email: {
        type: String,
        lowercase: true,
        unique: true,
        validate(v) {
            if (!validator.isEmail(v)) {
                throw new Error('invalid email')
            }
        }
    },
    password: {
        type: String,
        required: true
    }
})


// creating collection of userschema

const Admin = new mongoose.model('Admin', adminSchema);

module.exports = Admin

