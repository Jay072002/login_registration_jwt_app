const mongoose = require('mongoose');
const validator = require('validator')


// user schema 

const userSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    email: {
        type: String,
        lowercase: true,
        unique: true,
        validate(v) {
            if (!validator.isEmail(v)) {
                throw new Error('invalid email')
            }
        }
    },
    password: {
        type: String,
        required: true
    }
})


// creating collection of userschema

const User = new mongoose.model('User', userSchema);

const getData = async () => {
    try {

        const data = await User.find();//return arr of object
        return data;

    } catch (err) {
        console.log('error while getting Data', err);
    }
}

const getParticularData = async (email) => {
    try {
        const data = await User.findOne({ email: email });//return object
        return data;
    } catch (err) {
        console.log(err);
    }
}

const insertData = async (username, email, pwd) => {
    try {
        const newUser = new User({
            name: username,
            email: email,
            password: pwd
        })

        await newUser.save()

    } catch (err) {
        console.log(err);
    }
}

module.exports = {
    getData,
    insertData,
    getParticularData
}