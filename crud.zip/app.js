const express = require('express');
const cookieParser = require('cookie-parser');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT;

app.set('view engine', 'ejs')
app.use(express.urlencoded({ extended: true }))
app.use(cookieParser());

const user_route = require('./server/routes/user');
const auth_route = require('./server/routes/auth');;
const admin_route = require('./server/routes/admin');


app.use('/', user_route);
app.use('/auth', auth_route);
app.use('/auth', admin_route)

app.use(express.json());
app.use(express.static('public'));



app.listen(PORT, () => {
    console.log('server is running on port ', PORT);
})
